PetalPlot <- function(inputdata) {
  gg <- ggplot(data = inputdata, aes(x = Petal.Length, y = Petal.Width)) +
    geom_point(aes(color = Species, shape = Species)) +
    geom_smooth(method = lm) +
    annotate("text", x = 5, y = 0.5, label = "R=0.96")
  return(gg)
}